package com.mighty.explore_places_admin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
