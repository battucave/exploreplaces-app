import 'package:flutter/material.dart';

const primaryColor = Color(0xFF6AC6BB);
const selectIconColor = Color(0xffffffff);
const unSelectIconColor = Color(0xFFB3B1B1);
const secondaryColor = Color(0xFFFFFFFF);
const scaffoldColor = Color(0xFFF2F3FB);
const scaffoldColorDark = Color(0xFF090909);
const scaffoldSecondaryDark = Color(0xFF1E1E1E);
const appButtonColorDark = Color(0xFF282828);

