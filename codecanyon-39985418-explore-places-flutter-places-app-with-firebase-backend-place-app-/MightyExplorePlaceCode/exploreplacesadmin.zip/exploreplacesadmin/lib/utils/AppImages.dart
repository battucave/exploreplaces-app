const ic_appLogo = "assets/app_logo.jpg";
const ic_appLogo_transparent = 'assets/app_logo_transparent.png';
const login_bg = 'assets/login_bg.jpg';
const ic_login_logo = 'assets/icons/ic_login_logo.png';

const no_data = 'assets/no_data.png';
