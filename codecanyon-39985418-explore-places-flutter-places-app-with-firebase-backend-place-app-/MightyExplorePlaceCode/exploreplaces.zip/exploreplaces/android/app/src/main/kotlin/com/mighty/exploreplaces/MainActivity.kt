package com.mighty.exploreplaces

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
