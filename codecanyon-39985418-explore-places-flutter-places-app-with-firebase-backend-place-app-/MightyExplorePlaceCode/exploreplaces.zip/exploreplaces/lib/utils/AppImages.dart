const ic_appLogo = "assets/app_logo.jpg";
const ic_appLogo_transparent = 'assets/app_logo_transparent.png';
const login_logo_image = 'assets/login_logo_image.png';
const ic_about_us = "assets/icon/ic_about_us.png";
const ic_help_support = "assets/icon/ic_help_support.png";
const ic_language = "assets/icon/ic_language.png";
const ic_lock = "assets/icon/ic_lock.png";
const ic_login = "assets/icon/ic_login.png";
const ic_logout = "assets/icon/ic_logout.png";
const ic_privacy = "assets/icon/ic_privacy.png";
const ic_rate_us = "assets/icon/ic_rate_us.png";
const ic_terms_condition = "assets/icon/ic_terms_condition.png";
const ic_theme = "assets/icon/ic_theme.png";
const ic_delete_account = 'assets/icon/ic_delete_account.png';
const ic_places_request = 'assets/icon/ic_places_request.png';

const no_data = 'assets/no_data.png';
const loader = 'assets/loader.json';                                                              

const waterfall_image = "assets/waterfall.jpg";
const lake_image = "assets/lake.jpg";
const river_rafting_image = "assets/riverRafting.jpg";

