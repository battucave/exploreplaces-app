import '../models/WalkThroughModel.dart';
import 'AppImages.dart';

List<WalkThroughModel> walkThoughtList = [
  WalkThroughModel(
    image: waterfall_image,
    title: 'Waterfall',
    subTitle:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book",
  ),
  WalkThroughModel(
    image: lake_image,
    title: 'Lake',
    subTitle:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book",
  ),
  WalkThroughModel(
    image: river_rafting_image,
    title: 'River Rafting',
    subTitle:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book",
  ),
];

