import 'package:flutter/material.dart';

class WalkThroughModel {
  String? image;
  String? title;
  String? subTitle;
  Color? color;

  WalkThroughModel({this.image, this.title, this.subTitle, this.color});
}
